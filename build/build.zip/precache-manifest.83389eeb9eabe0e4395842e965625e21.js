self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7ccfba8aa44f0d2f4bd8e6201c17edf1",
    "url": "/user_manage/index.html"
  },
  {
    "revision": "76bbb8318a82d8b8e228",
    "url": "/user_manage/static/css/10.e2b4b4c5.chunk.css"
  },
  {
    "revision": "67ae81b2760579e25941",
    "url": "/user_manage/static/css/105.82cb759e.chunk.css"
  },
  {
    "revision": "ef3df313696f23953cf7",
    "url": "/user_manage/static/css/108.c9cb129a.chunk.css"
  },
  {
    "revision": "79107c70b3b01d86f58b",
    "url": "/user_manage/static/css/109.20628815.chunk.css"
  },
  {
    "revision": "29b67154eb5f25adb3af",
    "url": "/user_manage/static/css/111.4b8c302d.chunk.css"
  },
  {
    "revision": "4f8986ed08874e34e54c",
    "url": "/user_manage/static/css/112.7257c9de.chunk.css"
  },
  {
    "revision": "7c0f0df4276aa96105ea",
    "url": "/user_manage/static/css/113.7257c9de.chunk.css"
  },
  {
    "revision": "5bb1e3086510857afa29",
    "url": "/user_manage/static/css/114.7257c9de.chunk.css"
  },
  {
    "revision": "23b4f21534b1d2f89768",
    "url": "/user_manage/static/css/115.55a604e7.chunk.css"
  },
  {
    "revision": "ded12bdd5455e320ec70",
    "url": "/user_manage/static/css/116.c9cb129a.chunk.css"
  },
  {
    "revision": "96ad0246a402d6ce7023",
    "url": "/user_manage/static/css/117.c9cb129a.chunk.css"
  },
  {
    "revision": "9d69917b47c1b84afc9e",
    "url": "/user_manage/static/css/118.53419b26.chunk.css"
  },
  {
    "revision": "4373f8b75945838ecfbd",
    "url": "/user_manage/static/css/119.c9cb129a.chunk.css"
  },
  {
    "revision": "bc799b00440982e2eae9",
    "url": "/user_manage/static/css/121.0f5e4f44.chunk.css"
  },
  {
    "revision": "ae7d66f2776732581278",
    "url": "/user_manage/static/css/122.1323ac17.chunk.css"
  },
  {
    "revision": "fbbea8800935a0fdfcc2",
    "url": "/user_manage/static/css/124.b63add6c.chunk.css"
  },
  {
    "revision": "91d444d86f9b8a8a3cb4",
    "url": "/user_manage/static/css/125.28e6519a.chunk.css"
  },
  {
    "revision": "490bbd167089eda6e0ca",
    "url": "/user_manage/static/css/126.26da5209.chunk.css"
  },
  {
    "revision": "1a2d6c2f4b2505c7dcbd",
    "url": "/user_manage/static/css/127.1dd7aea6.chunk.css"
  },
  {
    "revision": "62308c5dcb86d395accd",
    "url": "/user_manage/static/css/128.c48aa879.chunk.css"
  },
  {
    "revision": "afd8ff695b0a4f360703",
    "url": "/user_manage/static/css/129.3243747a.chunk.css"
  },
  {
    "revision": "7d3c97de0a3c3d9b42f7",
    "url": "/user_manage/static/css/130.1fb8d715.chunk.css"
  },
  {
    "revision": "efc0772242132b10b193",
    "url": "/user_manage/static/css/134.0a328200.chunk.css"
  },
  {
    "revision": "e66bc3f0a48db94bda68",
    "url": "/user_manage/static/css/135.4b8c302d.chunk.css"
  },
  {
    "revision": "e2245c82fd629fecf0ec",
    "url": "/user_manage/static/css/136.4b8c302d.chunk.css"
  },
  {
    "revision": "0853883cf30f03e10112",
    "url": "/user_manage/static/css/137.3b9a1903.chunk.css"
  },
  {
    "revision": "86a2dea80f220c2a7601",
    "url": "/user_manage/static/css/138.619e98d1.chunk.css"
  },
  {
    "revision": "28e41e38bf02497e3af3",
    "url": "/user_manage/static/css/139.25ca3533.chunk.css"
  },
  {
    "revision": "091b1f6653a5538e2fb5",
    "url": "/user_manage/static/css/141.b4767b33.chunk.css"
  },
  {
    "revision": "e6cb41818e18a57e0411",
    "url": "/user_manage/static/css/143.90d1d166.chunk.css"
  },
  {
    "revision": "356782caf7f79ef64ad7",
    "url": "/user_manage/static/css/144.f65ef936.chunk.css"
  },
  {
    "revision": "190c26cd790372405813",
    "url": "/user_manage/static/css/16.3d06f600.chunk.css"
  },
  {
    "revision": "182bbc5f55bbfdb813c1",
    "url": "/user_manage/static/css/20.e2741bfe.chunk.css"
  },
  {
    "revision": "e9c817aa6fdb6d9b92e3",
    "url": "/user_manage/static/css/21.63865653.chunk.css"
  },
  {
    "revision": "b337df2d7323319a5fd5",
    "url": "/user_manage/static/css/22.5644f106.chunk.css"
  },
  {
    "revision": "ccf4e490bf8826f8f132",
    "url": "/user_manage/static/css/27.9d9e154e.chunk.css"
  },
  {
    "revision": "cf9fe3a7bd2d99f176f8",
    "url": "/user_manage/static/css/29.1c1a6b2d.chunk.css"
  },
  {
    "revision": "5dbebc0018d356ee75ee",
    "url": "/user_manage/static/css/31.0dde5e1c.chunk.css"
  },
  {
    "revision": "eee7ed8753cea8d47922",
    "url": "/user_manage/static/css/32.779e0824.chunk.css"
  },
  {
    "revision": "ac95512a3584912c3c24",
    "url": "/user_manage/static/css/34.8fe9f442.chunk.css"
  },
  {
    "revision": "5b68396e32677db30bc9",
    "url": "/user_manage/static/css/35.77422672.chunk.css"
  },
  {
    "revision": "6aefc1a64d7621a4d3ac",
    "url": "/user_manage/static/css/36.0e75630a.chunk.css"
  },
  {
    "revision": "dca9efea2b5992657ace",
    "url": "/user_manage/static/css/37.3b9a1903.chunk.css"
  },
  {
    "revision": "cf1d5a9e9f98919bd774",
    "url": "/user_manage/static/css/38.df359473.chunk.css"
  },
  {
    "revision": "1763d0c2b1edff19e200",
    "url": "/user_manage/static/css/39.bb27a029.chunk.css"
  },
  {
    "revision": "463160bff0bf59cddcb0",
    "url": "/user_manage/static/css/40.a876bdfb.chunk.css"
  },
  {
    "revision": "88367563b1685dcf1b84",
    "url": "/user_manage/static/css/41.ebbeb79d.chunk.css"
  },
  {
    "revision": "5f68d7736f160529d48f",
    "url": "/user_manage/static/css/42.3c580db7.chunk.css"
  },
  {
    "revision": "889c2d383a7f4bffc3a3",
    "url": "/user_manage/static/css/46.75e69532.chunk.css"
  },
  {
    "revision": "fa20631d3ba82342b112",
    "url": "/user_manage/static/css/47.938c68d3.chunk.css"
  },
  {
    "revision": "2a1aa54b7a4025167cbe",
    "url": "/user_manage/static/css/48.938c68d3.chunk.css"
  },
  {
    "revision": "79554dd221e8c58a6cdb",
    "url": "/user_manage/static/css/50.aaf81940.chunk.css"
  },
  {
    "revision": "7f809394c9fbe817d321",
    "url": "/user_manage/static/css/51.8eec7ea6.chunk.css"
  },
  {
    "revision": "4bda8e011cda3471a8c7",
    "url": "/user_manage/static/css/52.2c9a01e9.chunk.css"
  },
  {
    "revision": "4fadf0c4bb948195aff2",
    "url": "/user_manage/static/css/57.53419b26.chunk.css"
  },
  {
    "revision": "9db56eb9dd7f70677d7a",
    "url": "/user_manage/static/css/6.086b1f82.chunk.css"
  },
  {
    "revision": "4a6d4e2bbf80059acaca",
    "url": "/user_manage/static/css/62.1dd7aea6.chunk.css"
  },
  {
    "revision": "6e797ae744ce54ebee94",
    "url": "/user_manage/static/css/63.fe95317e.chunk.css"
  },
  {
    "revision": "ffe47e5fa410ee7d26ce",
    "url": "/user_manage/static/css/64.432d3d5e.chunk.css"
  },
  {
    "revision": "a8c38f0dc14fd6739576",
    "url": "/user_manage/static/css/70.e5a66023.chunk.css"
  },
  {
    "revision": "0590652c11ee2621bb56",
    "url": "/user_manage/static/css/71.25ca3533.chunk.css"
  },
  {
    "revision": "49327cc3de135f42fd51",
    "url": "/user_manage/static/css/72.938c68d3.chunk.css"
  },
  {
    "revision": "576dc99fc117cce11914",
    "url": "/user_manage/static/css/73.938c68d3.chunk.css"
  },
  {
    "revision": "1d394cfc8e10efb9ca2f",
    "url": "/user_manage/static/css/74.938c68d3.chunk.css"
  },
  {
    "revision": "0bcc48cba6064f104067",
    "url": "/user_manage/static/css/75.3243747a.chunk.css"
  },
  {
    "revision": "b8f52ed8b1e3e2bdced8",
    "url": "/user_manage/static/css/91.cc1ab497.chunk.css"
  },
  {
    "revision": "714dd063244a96cd9dbd",
    "url": "/user_manage/static/css/93.10f672ef.chunk.css"
  },
  {
    "revision": "bd78f12982b29cf844b7",
    "url": "/user_manage/static/css/main.72fb4b27.chunk.css"
  },
  {
    "revision": "3e811d5c3321353ea499",
    "url": "/user_manage/static/js/0.d7ea4eb1.chunk.js"
  },
  {
    "revision": "0e68a261e4846a1e390826c53c553105",
    "url": "/user_manage/static/js/0.d7ea4eb1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d2ab8978ac1146c3eabf",
    "url": "/user_manage/static/js/1.b108c6d5.chunk.js"
  },
  {
    "revision": "8e7fa176b006150306288bd092a696c0",
    "url": "/user_manage/static/js/1.b108c6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "76bbb8318a82d8b8e228",
    "url": "/user_manage/static/js/10.a41da3fc.chunk.js"
  },
  {
    "revision": "3e07632c4a805279a8ff",
    "url": "/user_manage/static/js/100.88ebcf7d.chunk.js"
  },
  {
    "revision": "8e652faf3e8f66d0aa4c",
    "url": "/user_manage/static/js/101.8d2d36f6.chunk.js"
  },
  {
    "revision": "5ec4e5b1fc1fb73cab6a",
    "url": "/user_manage/static/js/102.41e047dc.chunk.js"
  },
  {
    "revision": "52f521dc8e0d7b46e249",
    "url": "/user_manage/static/js/103.59ca8d82.chunk.js"
  },
  {
    "revision": "c987ae5e9e3e370da515",
    "url": "/user_manage/static/js/104.00714ff9.chunk.js"
  },
  {
    "revision": "67ae81b2760579e25941",
    "url": "/user_manage/static/js/105.fd1dc3ec.chunk.js"
  },
  {
    "revision": "c249b5e746bacaf0956d",
    "url": "/user_manage/static/js/106.a90ce7c4.chunk.js"
  },
  {
    "revision": "25fbacd9f2dd5e63324f",
    "url": "/user_manage/static/js/107.b1e73d91.chunk.js"
  },
  {
    "revision": "ef3df313696f23953cf7",
    "url": "/user_manage/static/js/108.19406b88.chunk.js"
  },
  {
    "revision": "79107c70b3b01d86f58b",
    "url": "/user_manage/static/js/109.7fddf566.chunk.js"
  },
  {
    "revision": "ac3fdb36ff1c5384a00b",
    "url": "/user_manage/static/js/11.bb4c44df.chunk.js"
  },
  {
    "revision": "1fa2298c1254c4345de7e1b8d2d7623f",
    "url": "/user_manage/static/js/11.bb4c44df.chunk.js.LICENSE.txt"
  },
  {
    "revision": "13536109ddae90ec1c9b",
    "url": "/user_manage/static/js/110.aeb8a5a1.chunk.js"
  },
  {
    "revision": "29b67154eb5f25adb3af",
    "url": "/user_manage/static/js/111.a593c7f3.chunk.js"
  },
  {
    "revision": "4f8986ed08874e34e54c",
    "url": "/user_manage/static/js/112.5a4d809a.chunk.js"
  },
  {
    "revision": "7c0f0df4276aa96105ea",
    "url": "/user_manage/static/js/113.d02a5d30.chunk.js"
  },
  {
    "revision": "5bb1e3086510857afa29",
    "url": "/user_manage/static/js/114.b11944cd.chunk.js"
  },
  {
    "revision": "23b4f21534b1d2f89768",
    "url": "/user_manage/static/js/115.e700d318.chunk.js"
  },
  {
    "revision": "ded12bdd5455e320ec70",
    "url": "/user_manage/static/js/116.3a99f90b.chunk.js"
  },
  {
    "revision": "96ad0246a402d6ce7023",
    "url": "/user_manage/static/js/117.b1c61b1e.chunk.js"
  },
  {
    "revision": "9d69917b47c1b84afc9e",
    "url": "/user_manage/static/js/118.ce2b6a81.chunk.js"
  },
  {
    "revision": "4373f8b75945838ecfbd",
    "url": "/user_manage/static/js/119.e35f8b9c.chunk.js"
  },
  {
    "revision": "a91939024a5aea9f00cf",
    "url": "/user_manage/static/js/12.1f8de516.chunk.js"
  },
  {
    "revision": "7ba01fc4cafeab2f026b",
    "url": "/user_manage/static/js/120.5a7795d8.chunk.js"
  },
  {
    "revision": "bc799b00440982e2eae9",
    "url": "/user_manage/static/js/121.4b4f4e18.chunk.js"
  },
  {
    "revision": "ae7d66f2776732581278",
    "url": "/user_manage/static/js/122.4e823134.chunk.js"
  },
  {
    "revision": "a9ee0a29cc810fa4f1ef",
    "url": "/user_manage/static/js/123.108a22ff.chunk.js"
  },
  {
    "revision": "fbbea8800935a0fdfcc2",
    "url": "/user_manage/static/js/124.c123f114.chunk.js"
  },
  {
    "revision": "91d444d86f9b8a8a3cb4",
    "url": "/user_manage/static/js/125.4a6bfb33.chunk.js"
  },
  {
    "revision": "490bbd167089eda6e0ca",
    "url": "/user_manage/static/js/126.6e402aa3.chunk.js"
  },
  {
    "revision": "1a2d6c2f4b2505c7dcbd",
    "url": "/user_manage/static/js/127.dc05554b.chunk.js"
  },
  {
    "revision": "62308c5dcb86d395accd",
    "url": "/user_manage/static/js/128.259cee02.chunk.js"
  },
  {
    "revision": "afd8ff695b0a4f360703",
    "url": "/user_manage/static/js/129.527fb617.chunk.js"
  },
  {
    "revision": "f2bef8c7b9802b274937",
    "url": "/user_manage/static/js/13.d5555985.chunk.js"
  },
  {
    "revision": "7d3c97de0a3c3d9b42f7",
    "url": "/user_manage/static/js/130.d0cac581.chunk.js"
  },
  {
    "revision": "41ab5158a7e46ff2fd56",
    "url": "/user_manage/static/js/131.23a25fbf.chunk.js"
  },
  {
    "revision": "ea87320556151b7c075f",
    "url": "/user_manage/static/js/132.c4e05582.chunk.js"
  },
  {
    "revision": "113e81ced127f4c636c3",
    "url": "/user_manage/static/js/133.a150b4ee.chunk.js"
  },
  {
    "revision": "efc0772242132b10b193",
    "url": "/user_manage/static/js/134.e56649b2.chunk.js"
  },
  {
    "revision": "e66bc3f0a48db94bda68",
    "url": "/user_manage/static/js/135.918640a7.chunk.js"
  },
  {
    "revision": "e2245c82fd629fecf0ec",
    "url": "/user_manage/static/js/136.f9a34719.chunk.js"
  },
  {
    "revision": "0853883cf30f03e10112",
    "url": "/user_manage/static/js/137.03f39565.chunk.js"
  },
  {
    "revision": "86a2dea80f220c2a7601",
    "url": "/user_manage/static/js/138.dff7974b.chunk.js"
  },
  {
    "revision": "28e41e38bf02497e3af3",
    "url": "/user_manage/static/js/139.8208d3b9.chunk.js"
  },
  {
    "revision": "62580a332a40e26a2279",
    "url": "/user_manage/static/js/14.15d52279.chunk.js"
  },
  {
    "revision": "2dccd194985bbbf58ef6",
    "url": "/user_manage/static/js/140.bef62710.chunk.js"
  },
  {
    "revision": "091b1f6653a5538e2fb5",
    "url": "/user_manage/static/js/141.958a0761.chunk.js"
  },
  {
    "revision": "7cab26840bcac4525d48",
    "url": "/user_manage/static/js/142.4031d1f5.chunk.js"
  },
  {
    "revision": "e6cb41818e18a57e0411",
    "url": "/user_manage/static/js/143.7be863a9.chunk.js"
  },
  {
    "revision": "356782caf7f79ef64ad7",
    "url": "/user_manage/static/js/144.a28e4e23.chunk.js"
  },
  {
    "revision": "89f11d7447db2228e381",
    "url": "/user_manage/static/js/145.b50b5537.chunk.js"
  },
  {
    "revision": "a70d10721db77d345ac0",
    "url": "/user_manage/static/js/146.711cfe30.chunk.js"
  },
  {
    "revision": "d51c699b4357cb37dcc86d11129f128d",
    "url": "/user_manage/static/js/146.711cfe30.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8a13580aecc01f4eac6b",
    "url": "/user_manage/static/js/147.68f158b0.chunk.js"
  },
  {
    "revision": "038d2a9cdf8090ffd2bb",
    "url": "/user_manage/static/js/148.106eccf9.chunk.js"
  },
  {
    "revision": "1cbc30cbb237dbf9d21e",
    "url": "/user_manage/static/js/149.5876c0eb.chunk.js"
  },
  {
    "revision": "f9d0fa1a6c23e77dda6f",
    "url": "/user_manage/static/js/15.a5024cc0.chunk.js"
  },
  {
    "revision": "1f6402cb9e6f6188e310",
    "url": "/user_manage/static/js/150.be0968b9.chunk.js"
  },
  {
    "revision": "e351384374a6070fd827",
    "url": "/user_manage/static/js/151.ca011afc.chunk.js"
  },
  {
    "revision": "fbe2000714009d05d73c",
    "url": "/user_manage/static/js/152.01840ad3.chunk.js"
  },
  {
    "revision": "6defdbcc4d1327c61e69",
    "url": "/user_manage/static/js/153.ce55ca75.chunk.js"
  },
  {
    "revision": "1db279e336c77b285e85",
    "url": "/user_manage/static/js/154.9ac41fa8.chunk.js"
  },
  {
    "revision": "7a0b13786ee2a4c58449",
    "url": "/user_manage/static/js/155.745a4cca.chunk.js"
  },
  {
    "revision": "26c69b238aaa35ab38d0",
    "url": "/user_manage/static/js/156.156df6e2.chunk.js"
  },
  {
    "revision": "4c6e97fed167db30c60f",
    "url": "/user_manage/static/js/157.b0f17b24.chunk.js"
  },
  {
    "revision": "9d6bd7e546cc67c8ec76",
    "url": "/user_manage/static/js/158.a25e05b8.chunk.js"
  },
  {
    "revision": "27a55ae4160c1ab5742c",
    "url": "/user_manage/static/js/159.6052d564.chunk.js"
  },
  {
    "revision": "190c26cd790372405813",
    "url": "/user_manage/static/js/16.fe7233eb.chunk.js"
  },
  {
    "revision": "8ceff2ac9bc58654f6e5cd90830d4f26",
    "url": "/user_manage/static/js/16.fe7233eb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97be73fac169b8aaba4a",
    "url": "/user_manage/static/js/160.16971257.chunk.js"
  },
  {
    "revision": "25ca929861412cffc40a",
    "url": "/user_manage/static/js/161.582f8744.chunk.js"
  },
  {
    "revision": "6a948e9ee547d306249b",
    "url": "/user_manage/static/js/162.d09c59c1.chunk.js"
  },
  {
    "revision": "1bf750125964308f0d64",
    "url": "/user_manage/static/js/17.ef590166.chunk.js"
  },
  {
    "revision": "8a2ec2602bf34c44a0fc",
    "url": "/user_manage/static/js/18.9691a03f.chunk.js"
  },
  {
    "revision": "50c32b82ffbf01ea0786",
    "url": "/user_manage/static/js/19.8a93bd53.chunk.js"
  },
  {
    "revision": "51fb3c47bff2207b3ec3",
    "url": "/user_manage/static/js/2.1a8336f4.chunk.js"
  },
  {
    "revision": "fcc593daad6eaf3af12e90a9065adf81",
    "url": "/user_manage/static/js/2.1a8336f4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "182bbc5f55bbfdb813c1",
    "url": "/user_manage/static/js/20.35d27ffe.chunk.js"
  },
  {
    "revision": "e9c817aa6fdb6d9b92e3",
    "url": "/user_manage/static/js/21.05409161.chunk.js"
  },
  {
    "revision": "b337df2d7323319a5fd5",
    "url": "/user_manage/static/js/22.bf0617a8.chunk.js"
  },
  {
    "revision": "66d710dc88a67d3fce90",
    "url": "/user_manage/static/js/23.c9e61417.chunk.js"
  },
  {
    "revision": "6a8881f13fa14ec563ab",
    "url": "/user_manage/static/js/24.8f4d7cc7.chunk.js"
  },
  {
    "revision": "ccf4e490bf8826f8f132",
    "url": "/user_manage/static/js/27.be18be1b.chunk.js"
  },
  {
    "revision": "543ecb9028a7a0fa902a1beb1f81c3d6",
    "url": "/user_manage/static/js/27.be18be1b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7cb89f8a8d6cb475c4be",
    "url": "/user_manage/static/js/28.61c2f1b0.chunk.js"
  },
  {
    "revision": "7bbfdfaa620dfc65b72502e4aad0eb44",
    "url": "/user_manage/static/js/28.61c2f1b0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cf9fe3a7bd2d99f176f8",
    "url": "/user_manage/static/js/29.ab3cfeb5.chunk.js"
  },
  {
    "revision": "9e0072d814c3d1f3c328",
    "url": "/user_manage/static/js/3.affc80b0.chunk.js"
  },
  {
    "revision": "9aca4389a84af5a1529a",
    "url": "/user_manage/static/js/30.7d21edbb.chunk.js"
  },
  {
    "revision": "01d4c4af70b74f2309f9683b2e8844d8",
    "url": "/user_manage/static/js/30.7d21edbb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5dbebc0018d356ee75ee",
    "url": "/user_manage/static/js/31.1daced5a.chunk.js"
  },
  {
    "revision": "eee7ed8753cea8d47922",
    "url": "/user_manage/static/js/32.17d022ab.chunk.js"
  },
  {
    "revision": "cf70868a05e1cbff534b",
    "url": "/user_manage/static/js/33.9293920b.chunk.js"
  },
  {
    "revision": "223e1043e6c92cd5b8490b603521d509",
    "url": "/user_manage/static/js/33.9293920b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ac95512a3584912c3c24",
    "url": "/user_manage/static/js/34.961f2e35.chunk.js"
  },
  {
    "revision": "5b68396e32677db30bc9",
    "url": "/user_manage/static/js/35.daa07077.chunk.js"
  },
  {
    "revision": "6aefc1a64d7621a4d3ac",
    "url": "/user_manage/static/js/36.ef99dfa3.chunk.js"
  },
  {
    "revision": "dca9efea2b5992657ace",
    "url": "/user_manage/static/js/37.898a04e3.chunk.js"
  },
  {
    "revision": "cf1d5a9e9f98919bd774",
    "url": "/user_manage/static/js/38.1b3c68a1.chunk.js"
  },
  {
    "revision": "1763d0c2b1edff19e200",
    "url": "/user_manage/static/js/39.a80b89b2.chunk.js"
  },
  {
    "revision": "edea6328bc445e6dc176",
    "url": "/user_manage/static/js/4.5cbab728.chunk.js"
  },
  {
    "revision": "463160bff0bf59cddcb0",
    "url": "/user_manage/static/js/40.2ed82212.chunk.js"
  },
  {
    "revision": "88367563b1685dcf1b84",
    "url": "/user_manage/static/js/41.9dc0fcbe.chunk.js"
  },
  {
    "revision": "5f68d7736f160529d48f",
    "url": "/user_manage/static/js/42.72dfd7fa.chunk.js"
  },
  {
    "revision": "00060107ac0f8495cd50",
    "url": "/user_manage/static/js/43.7316c724.chunk.js"
  },
  {
    "revision": "9014f75bee2b03e13e1876e3edc1005c",
    "url": "/user_manage/static/js/43.7316c724.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2bf308c6c12fce9f228b",
    "url": "/user_manage/static/js/44.328c20d7.chunk.js"
  },
  {
    "revision": "d5589f1c5560d06e913f",
    "url": "/user_manage/static/js/45.84499d40.chunk.js"
  },
  {
    "revision": "889c2d383a7f4bffc3a3",
    "url": "/user_manage/static/js/46.3f488c19.chunk.js"
  },
  {
    "revision": "fa20631d3ba82342b112",
    "url": "/user_manage/static/js/47.87b3f179.chunk.js"
  },
  {
    "revision": "2a1aa54b7a4025167cbe",
    "url": "/user_manage/static/js/48.5a77a6ae.chunk.js"
  },
  {
    "revision": "dc89760b870f6928835f",
    "url": "/user_manage/static/js/49.58c3ae8b.chunk.js"
  },
  {
    "revision": "7bbcbd9448cdad0b8074",
    "url": "/user_manage/static/js/5.ef20f852.chunk.js"
  },
  {
    "revision": "362cd232e6b400756e3bc1723069a8cd",
    "url": "/user_manage/static/js/5.ef20f852.chunk.js.LICENSE.txt"
  },
  {
    "revision": "79554dd221e8c58a6cdb",
    "url": "/user_manage/static/js/50.bf110feb.chunk.js"
  },
  {
    "revision": "7f809394c9fbe817d321",
    "url": "/user_manage/static/js/51.5d50c2be.chunk.js"
  },
  {
    "revision": "4bda8e011cda3471a8c7",
    "url": "/user_manage/static/js/52.ecc18433.chunk.js"
  },
  {
    "revision": "d51c699b4357cb37dcc86d11129f128d",
    "url": "/user_manage/static/js/52.ecc18433.chunk.js.LICENSE.txt"
  },
  {
    "revision": "aea8793871d530cbba2b",
    "url": "/user_manage/static/js/53.e3b484af.chunk.js"
  },
  {
    "revision": "62b28e1cd49595d25109fe48f39df79c",
    "url": "/user_manage/static/js/53.e3b484af.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e40f889d7ca913a99d05",
    "url": "/user_manage/static/js/54.03e9b4b8.chunk.js"
  },
  {
    "revision": "98a06c64b1a4f795cc04",
    "url": "/user_manage/static/js/55.e4b9426a.chunk.js"
  },
  {
    "revision": "101a412557e06cea958b",
    "url": "/user_manage/static/js/56.ff99646d.chunk.js"
  },
  {
    "revision": "4fadf0c4bb948195aff2",
    "url": "/user_manage/static/js/57.89df80ba.chunk.js"
  },
  {
    "revision": "6ef0cac1557876405755",
    "url": "/user_manage/static/js/58.ec07e350.chunk.js"
  },
  {
    "revision": "2272e8a5c1b8e41f56a2",
    "url": "/user_manage/static/js/59.dc97ab7a.chunk.js"
  },
  {
    "revision": "9db56eb9dd7f70677d7a",
    "url": "/user_manage/static/js/6.fff488dc.chunk.js"
  },
  {
    "revision": "c15e1a5f0ad507aaff8fba85f60e0c7e",
    "url": "/user_manage/static/js/6.fff488dc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d55603fb23ef3dba2be2",
    "url": "/user_manage/static/js/60.3396d617.chunk.js"
  },
  {
    "revision": "1ddc1e9686a64410a087",
    "url": "/user_manage/static/js/61.a722a6f4.chunk.js"
  },
  {
    "revision": "4a6d4e2bbf80059acaca",
    "url": "/user_manage/static/js/62.18428cfb.chunk.js"
  },
  {
    "revision": "6e797ae744ce54ebee94",
    "url": "/user_manage/static/js/63.11e841c4.chunk.js"
  },
  {
    "revision": "ffe47e5fa410ee7d26ce",
    "url": "/user_manage/static/js/64.d0eb363c.chunk.js"
  },
  {
    "revision": "4fbda7852619529cfd91",
    "url": "/user_manage/static/js/65.7d9f95e3.chunk.js"
  },
  {
    "revision": "6ae1cd73b032ebbc4f3c",
    "url": "/user_manage/static/js/66.354ebd14.chunk.js"
  },
  {
    "revision": "5f83edf8251ebb32244f",
    "url": "/user_manage/static/js/67.03c1ccd0.chunk.js"
  },
  {
    "revision": "1f1b8c024c6099d37207",
    "url": "/user_manage/static/js/68.37567595.chunk.js"
  },
  {
    "revision": "7f28d9caf91d52cf83f7",
    "url": "/user_manage/static/js/69.78b3e7bf.chunk.js"
  },
  {
    "revision": "8bfc66be7917131aee07",
    "url": "/user_manage/static/js/7.0239e85f.chunk.js"
  },
  {
    "revision": "707dfe35f053bcb0b7ad4b41c628535b",
    "url": "/user_manage/static/js/7.0239e85f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a8c38f0dc14fd6739576",
    "url": "/user_manage/static/js/70.a5315c83.chunk.js"
  },
  {
    "revision": "0590652c11ee2621bb56",
    "url": "/user_manage/static/js/71.7ce42c4a.chunk.js"
  },
  {
    "revision": "49327cc3de135f42fd51",
    "url": "/user_manage/static/js/72.7866ed2b.chunk.js"
  },
  {
    "revision": "576dc99fc117cce11914",
    "url": "/user_manage/static/js/73.17c73289.chunk.js"
  },
  {
    "revision": "1d394cfc8e10efb9ca2f",
    "url": "/user_manage/static/js/74.6c9d4207.chunk.js"
  },
  {
    "revision": "0bcc48cba6064f104067",
    "url": "/user_manage/static/js/75.eeccb9b5.chunk.js"
  },
  {
    "revision": "061144eeb311595a4efd",
    "url": "/user_manage/static/js/76.79f3b5c5.chunk.js"
  },
  {
    "revision": "99766c93d1ff7a06ed48",
    "url": "/user_manage/static/js/77.50880fec.chunk.js"
  },
  {
    "revision": "b924304db4706fdc4537",
    "url": "/user_manage/static/js/78.b5501757.chunk.js"
  },
  {
    "revision": "db0f31ebe46afa8a16ab",
    "url": "/user_manage/static/js/79.58ea3965.chunk.js"
  },
  {
    "revision": "b71054f5ac37d9fd450f",
    "url": "/user_manage/static/js/8.e40b3cfc.chunk.js"
  },
  {
    "revision": "c71bdc52421571d23560",
    "url": "/user_manage/static/js/80.403a006c.chunk.js"
  },
  {
    "revision": "e74c7054e05e7b2ce761",
    "url": "/user_manage/static/js/81.f19a934b.chunk.js"
  },
  {
    "revision": "994802d318a42e21c109",
    "url": "/user_manage/static/js/82.d109e469.chunk.js"
  },
  {
    "revision": "3425b3f6f801c2aa39d4",
    "url": "/user_manage/static/js/83.4805e6d5.chunk.js"
  },
  {
    "revision": "f6f316f2baf99e012c82",
    "url": "/user_manage/static/js/84.4b9c4a54.chunk.js"
  },
  {
    "revision": "68660c5ceabe1e872dab",
    "url": "/user_manage/static/js/85.64ae6d71.chunk.js"
  },
  {
    "revision": "447db764e4f2cd5e1f74",
    "url": "/user_manage/static/js/86.abf7a22e.chunk.js"
  },
  {
    "revision": "0252b19864d21d980ad0",
    "url": "/user_manage/static/js/87.669faaab.chunk.js"
  },
  {
    "revision": "36983d6c6674b0790fcf",
    "url": "/user_manage/static/js/88.1b3a3233.chunk.js"
  },
  {
    "revision": "cfc26665836da8e68898",
    "url": "/user_manage/static/js/89.da13b630.chunk.js"
  },
  {
    "revision": "302120fb2587477ea7e1",
    "url": "/user_manage/static/js/9.b7c82ae8.chunk.js"
  },
  {
    "revision": "975910aeb234f786f163",
    "url": "/user_manage/static/js/90.d68257db.chunk.js"
  },
  {
    "revision": "b8f52ed8b1e3e2bdced8",
    "url": "/user_manage/static/js/91.827bc217.chunk.js"
  },
  {
    "revision": "8cfb072f4d9b4335aa6e",
    "url": "/user_manage/static/js/92.255efc95.chunk.js"
  },
  {
    "revision": "714dd063244a96cd9dbd",
    "url": "/user_manage/static/js/93.feeae852.chunk.js"
  },
  {
    "revision": "38ad238fa83e5b16454f",
    "url": "/user_manage/static/js/94.b745a2b5.chunk.js"
  },
  {
    "revision": "07fe5d747509f5607e7f",
    "url": "/user_manage/static/js/95.2042e3bb.chunk.js"
  },
  {
    "revision": "65599371188721a11ebd",
    "url": "/user_manage/static/js/96.e8062420.chunk.js"
  },
  {
    "revision": "819697e1c1b99061814e",
    "url": "/user_manage/static/js/97.aa4b6163.chunk.js"
  },
  {
    "revision": "93a859862854cdd629c0",
    "url": "/user_manage/static/js/98.9140a084.chunk.js"
  },
  {
    "revision": "627a1a9e41f7ccfb0271",
    "url": "/user_manage/static/js/99.3c7c9afe.chunk.js"
  },
  {
    "revision": "bd78f12982b29cf844b7",
    "url": "/user_manage/static/js/main.f5e64dbc.chunk.js"
  },
  {
    "revision": "fd4c90081357ec9742d3",
    "url": "/user_manage/static/js/runtime-main.6c73151f.js"
  },
  {
    "revision": "68c25447bcf4497d03268dab4c36eba9",
    "url": "/user_manage/static/media/01.68c25447.jpg"
  },
  {
    "revision": "28f1f6c1bd64dd3e3bf91bb4e51d6315",
    "url": "/user_manage/static/media/02.28f1f6c1.jpg"
  },
  {
    "revision": "f098ec19aeefb6d18944bfe5cfcf8d2a",
    "url": "/user_manage/static/media/03.f098ec19.jpg"
  },
  {
    "revision": "142989c0de8605d2de491923d868e707",
    "url": "/user_manage/static/media/04.142989c0.jpg"
  },
  {
    "revision": "f45463a139721ed559d645d3c57967f8",
    "url": "/user_manage/static/media/05.f45463a1.jpg"
  },
  {
    "revision": "788aa261f5ea565091bd1057600098b6",
    "url": "/user_manage/static/media/06.788aa261.jpg"
  },
  {
    "revision": "3d505263723a9280555e31c58c7b73b5",
    "url": "/user_manage/static/media/1.3d505263.png"
  },
  {
    "revision": "b1a428ff98a282a0ef5ba7d46e875485",
    "url": "/user_manage/static/media/10.b1a428ff.png"
  },
  {
    "revision": "a75f0effa83383a53782d2f5324c3290",
    "url": "/user_manage/static/media/11.a75f0eff.png"
  },
  {
    "revision": "ef99742df71eb3907171fcfcd288d29a",
    "url": "/user_manage/static/media/2.ef99742d.png"
  },
  {
    "revision": "fedb99d5c4bc8797fb8ff1c95fecfaea",
    "url": "/user_manage/static/media/2.fedb99d5.jpg"
  },
  {
    "revision": "e002b22a14a8074e8d6d68450110587d",
    "url": "/user_manage/static/media/25.e002b22a.jpg"
  },
  {
    "revision": "ca194d41f35ff22f4f4321d8e6be8216",
    "url": "/user_manage/static/media/3.ca194d41.png"
  },
  {
    "revision": "abc79dc5f14b860941d05afab88d2ce0",
    "url": "/user_manage/static/media/4.abc79dc5.png"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/user_manage/static/media/404.3c60e090.png"
  },
  {
    "revision": "e9ee235e52e284f088f423b8f48477b2",
    "url": "/user_manage/static/media/5.e9ee235e.png"
  },
  {
    "revision": "7f467a0c37f3cc73afbd359f550b9e7b",
    "url": "/user_manage/static/media/500.7f467a0c.png"
  },
  {
    "revision": "847b1870b27051ad427b2f1fbf25dac4",
    "url": "/user_manage/static/media/6.847b1870.png"
  },
  {
    "revision": "0b1bc286923c9b8bd5cedf4cc1446e8e",
    "url": "/user_manage/static/media/7.0b1bc286.png"
  },
  {
    "revision": "8dfe9edc5f5eec2d5e4c89bd458f9c44",
    "url": "/user_manage/static/media/8.8dfe9edc.png"
  },
  {
    "revision": "3ea855615480dbb1e486bf73a3adf24a",
    "url": "/user_manage/static/media/9.3ea85561.png"
  },
  {
    "revision": "c51a5f8c467153ef51b6275e0c0a32fb",
    "url": "/user_manage/static/media/apple-watch.c51a5f8c.png"
  },
  {
    "revision": "4a4c28063dd7bd0409cf9a06d2513281",
    "url": "/user_manage/static/media/banner-1.4a4c2806.jpg"
  },
  {
    "revision": "c4ea0738fbef0fe2bf932b2f09e35ae2",
    "url": "/user_manage/static/media/banner-11.c4ea0738.jpg"
  },
  {
    "revision": "524ab3d0eacac9b9093477e5f785ca1e",
    "url": "/user_manage/static/media/banner-12.524ab3d0.jpg"
  },
  {
    "revision": "e1d5ec690362a7af2cf5f5be6e06d34d",
    "url": "/user_manage/static/media/banner-13.e1d5ec69.jpg"
  },
  {
    "revision": "c940cda3b811642ab6dcd7707ca389e1",
    "url": "/user_manage/static/media/banner-14.c940cda3.jpg"
  },
  {
    "revision": "debcc8c25de6c8a1be9e0f65991582b2",
    "url": "/user_manage/static/media/banner-15.debcc8c2.jpg"
  },
  {
    "revision": "e6244c2ad169686e0cbcc2f5a5f32b62",
    "url": "/user_manage/static/media/banner-2.e6244c2a.jpg"
  },
  {
    "revision": "702fed4d6b4373d53290ebc05578758b",
    "url": "/user_manage/static/media/banner-22.702fed4d.jpg"
  },
  {
    "revision": "b74d240c097fcaaa84296460c03a55eb",
    "url": "/user_manage/static/media/banner-23.b74d240c.jpg"
  },
  {
    "revision": "d3fb51a802b66461de9e00f53920bde9",
    "url": "/user_manage/static/media/banner-24.d3fb51a8.jpg"
  },
  {
    "revision": "a47593fcb283225136bb8d53686d194b",
    "url": "/user_manage/static/media/banner-25.a47593fc.jpg"
  },
  {
    "revision": "47a61bf48d2ae3a71df09d0312bc4c42",
    "url": "/user_manage/static/media/banner-26.47a61bf4.jpg"
  },
  {
    "revision": "d91487ffc8f67735b639f882556f208f",
    "url": "/user_manage/static/media/banner-28.d91487ff.jpg"
  },
  {
    "revision": "27e939158b498b6e1c9510a8b88e8d86",
    "url": "/user_manage/static/media/banner-29.27e93915.jpg"
  },
  {
    "revision": "bf5bb3db9cbbbfe49b111d3f6f7bddc5",
    "url": "/user_manage/static/media/banner-3.bf5bb3db.jpg"
  },
  {
    "revision": "56f1c6a1dc376db60555577aa073f452",
    "url": "/user_manage/static/media/banner-30.56f1c6a1.jpg"
  },
  {
    "revision": "d54fc4be7159141a04545b3bb4dd10be",
    "url": "/user_manage/static/media/banner-31.d54fc4be.jpg"
  },
  {
    "revision": "ee83ec3d018649a8da94da3dcc1cb88e",
    "url": "/user_manage/static/media/banner-32.ee83ec3d.jpg"
  },
  {
    "revision": "5857ec71ddd1a8682427cacf86008e42",
    "url": "/user_manage/static/media/banner-33.5857ec71.jpg"
  },
  {
    "revision": "61156fc900a89546a5f190c62f9be7c2",
    "url": "/user_manage/static/media/banner-34.61156fc9.jpg"
  },
  {
    "revision": "3aadcbe262b076b0cfc2d2d7742efc88",
    "url": "/user_manage/static/media/banner-35.3aadcbe2.jpg"
  },
  {
    "revision": "78c06c6426580ca51a74c49a792198fe",
    "url": "/user_manage/static/media/banner-36.78c06c64.jpg"
  },
  {
    "revision": "4e9e51f820a183c4ae911b16afa46a46",
    "url": "/user_manage/static/media/banner-37.4e9e51f8.jpg"
  },
  {
    "revision": "adcd1e2f659909ec1845d673442b115d",
    "url": "/user_manage/static/media/banner-39.adcd1e2f.jpg"
  },
  {
    "revision": "9f527fa04a6234b305c2ef4b985c229d",
    "url": "/user_manage/static/media/banner-4.9f527fa0.jpg"
  },
  {
    "revision": "e373069d444664058c827aa696ae31d4",
    "url": "/user_manage/static/media/banner-5.e373069d.jpg"
  },
  {
    "revision": "2b57003e5322e064b8ac8ba688d038b8",
    "url": "/user_manage/static/media/banner-7.2b57003e.jpg"
  },
  {
    "revision": "4d8cd617a438b1865d8bcc9b9f0e527c",
    "url": "/user_manage/static/media/banner-8.4d8cd617.jpg"
  },
  {
    "revision": "2538d7f4b2ee8bffc0fcf138bc30dd66",
    "url": "/user_manage/static/media/beats-headphones.2538d7f4.png"
  },
  {
    "revision": "1d0e6cb083962593b170d1154065c588",
    "url": "/user_manage/static/media/canon-camera.1d0e6cb0.jpg"
  },
  {
    "revision": "4d0da371873f415573e9ac1545770c43",
    "url": "/user_manage/static/media/card-image-5.4d0da371.jpg"
  },
  {
    "revision": "bcb47f7318ab063b783bbdd3dc801b0b",
    "url": "/user_manage/static/media/card-image-6.bcb47f73.jpg"
  },
  {
    "revision": "464708c291f0046e92cb7a6d708d7159",
    "url": "/user_manage/static/media/chat-bg.464708c2.svg"
  },
  {
    "revision": "9ed97ef017b0518d137eecc1614709ba",
    "url": "/user_manage/static/media/content-img-1.9ed97ef0.jpg"
  },
  {
    "revision": "b1cebdc7040e967e9b54946688e3368c",
    "url": "/user_manage/static/media/content-img-2.b1cebdc7.jpg"
  },
  {
    "revision": "de04600a319a9d5f2681c1b0fbf97402",
    "url": "/user_manage/static/media/content-img-3.de04600a.jpg"
  },
  {
    "revision": "c8c9986d072d0fd1e200675094f8542b",
    "url": "/user_manage/static/media/content-img-4.c8c9986d.jpg"
  },
  {
    "revision": "8446b2584e45d95d7a2ddab601d4a3fe",
    "url": "/user_manage/static/media/contract_logo.8446b258.jpg"
  },
  {
    "revision": "21a4037c42d00cae2278abc7225d514e",
    "url": "/user_manage/static/media/cover.21a4037c.jpg"
  },
  {
    "revision": "360bdee96b1a447d2ed5b53e18281d91",
    "url": "/user_manage/static/media/eor.360bdee9.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/user_manage/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/user_manage/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/user_manage/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/user_manage/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b23df4db71a29dbb733a0e555a7db8f9",
    "url": "/user_manage/static/media/feather.b23df4db.svg"
  },
  {
    "revision": "63f5a96a010605a3708c757d6c28f26f",
    "url": "/user_manage/static/media/forgot-password.63f5a96a.png"
  },
  {
    "revision": "58c221eb634672a81e993b0d504b817e",
    "url": "/user_manage/static/media/graphic-1.58c221eb.png"
  },
  {
    "revision": "6dd844b4e1c23397034730767a9cd80f",
    "url": "/user_manage/static/media/graphic-2.6dd844b4.png"
  },
  {
    "revision": "32e0e0cbbff3e818fab9a85ef4ad3049",
    "url": "/user_manage/static/media/graphic-3.32e0e0cb.png"
  },
  {
    "revision": "0112e6802d366ef7245eacd6d01819bb",
    "url": "/user_manage/static/media/graphic-4.0112e680.png"
  },
  {
    "revision": "e641549914a09612ddf229de04a13ab6",
    "url": "/user_manage/static/media/graphic-5.e6415499.png"
  },
  {
    "revision": "4df5e78b8bccc17c1d773533f28caab3",
    "url": "/user_manage/static/media/graphic-6.4df5e78b.png"
  },
  {
    "revision": "e317263497178bc42064efeb9119d85c",
    "url": "/user_manage/static/media/homepod.e3172634.png"
  },
  {
    "revision": "df7d34303f0e52c8ea7278f52c3b9826",
    "url": "/user_manage/static/media/ipad-pro.df7d3430.png"
  },
  {
    "revision": "ff1daa9ec97c4edc151eedaea4082345",
    "url": "/user_manage/static/media/iphone-x.ff1daa9e.png"
  },
  {
    "revision": "66807511376bd843f269ef71f9fba3e1",
    "url": "/user_manage/static/media/jbl-speaker.66807511.png"
  },
  {
    "revision": "034f99d6b318ef066c3da40de3d2e26d",
    "url": "/user_manage/static/media/kb-article.034f99d6.jpg"
  },
  {
    "revision": "254ae2dfebb5476285cb53af3d2fbd4a",
    "url": "/user_manage/static/media/knowledge-base-cover.254ae2df.jpg"
  },
  {
    "revision": "2fd8622a92c36fa9c416c79d865ab8fb",
    "url": "/user_manage/static/media/lock-screen.2fd8622a.png"
  },
  {
    "revision": "fd58a052054c690506118c4b7a0f731d",
    "url": "/user_manage/static/media/login.fd58a052.png"
  },
  {
    "revision": "e723c891248adeb4e66a9976624171f3",
    "url": "/user_manage/static/media/macbook-pro.e723c891.png"
  },
  {
    "revision": "3cf7a781374f77d1cf1068a78d3ec9d1",
    "url": "/user_manage/static/media/magic-mouse.3cf7a781.png"
  },
  {
    "revision": "6cada7e00e9d66aa310184d2318d68c0",
    "url": "/user_manage/static/media/maintenance-2.6cada7e0.png"
  },
  {
    "revision": "fd14a94730dd142d73460d8781c599e8",
    "url": "/user_manage/static/media/map-marker.fd14a947.png"
  },
  {
    "revision": "80c137f68bccbb3f2725951377165ab3",
    "url": "/user_manage/static/media/modern.80c137f6.jpg"
  },
  {
    "revision": "0ac6340e220a73cf86f487a7e751ee9b",
    "url": "/user_manage/static/media/not-authorized.0ac6340e.png"
  },
  {
    "revision": "5bd4d3ccc27a6b4370392a926030a1a5",
    "url": "/user_manage/static/media/page-03.5bd4d3cc.jpg"
  },
  {
    "revision": "2078495e9097021961ad633e46594ee5",
    "url": "/user_manage/static/media/page-05.2078495e.jpg"
  },
  {
    "revision": "ccdd96d254f175d74851a4c35a988290",
    "url": "/user_manage/static/media/page-09.ccdd96d2.jpg"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/user_manage/static/media/parallax-4.e4562786.jpg"
  },
  {
    "revision": "23d1bae7ef4c0758e2b374755de5557e",
    "url": "/user_manage/static/media/register.23d1bae7.jpg"
  },
  {
    "revision": "01a139f9cdd57337bcf899cc08d032ac",
    "url": "/user_manage/static/media/reset-password.01a139f9.png"
  },
  {
    "revision": "7357edb22819a1b632cf4a87bacff330",
    "url": "/user_manage/static/media/search-result.7357edb2.jpg"
  },
  {
    "revision": "9f82c4b3494f8982c2d0c278cd12ba3d",
    "url": "/user_manage/static/media/sony-75class-tv.9f82c4b3.jpg"
  },
  {
    "revision": "89267f25cff88340f0aabc24e127e8a2",
    "url": "/user_manage/static/media/transparent.89267f25.svg"
  },
  {
    "revision": "a8479cb8c6545103efcb6c183b566fca",
    "url": "/user_manage/static/media/user-01.a8479cb8.jpg"
  },
  {
    "revision": "8342b4cbcd1d190441fac85147759149",
    "url": "/user_manage/static/media/user-02.8342b4cb.jpg"
  },
  {
    "revision": "0fc73648270a763834c576f0055cc2b4",
    "url": "/user_manage/static/media/user-03.0fc73648.jpg"
  },
  {
    "revision": "3ac7ddd34b5c7e54ee2ccb7138a46006",
    "url": "/user_manage/static/media/user-04.3ac7ddd3.jpg"
  },
  {
    "revision": "d2e525385c91e6d0ac0218a30b46a6f2",
    "url": "/user_manage/static/media/user-05.d2e52538.jpg"
  },
  {
    "revision": "74a75a96632ab8a887f3538db6c9bd87",
    "url": "/user_manage/static/media/user-06.74a75a96.jpg"
  },
  {
    "revision": "c63e602a7de55084201e27fa126501d1",
    "url": "/user_manage/static/media/user-07.c63e602a.jpg"
  },
  {
    "revision": "d01a17e3caa757f0e23e810f4ea3d982",
    "url": "/user_manage/static/media/user-08.d01a17e3.jpg"
  },
  {
    "revision": "ed018c7b7fc86081ea7245e8c4f098d8",
    "url": "/user_manage/static/media/user-09.ed018c7b.jpg"
  },
  {
    "revision": "005c80e1c92c2c0bc620bf3168f9a53c",
    "url": "/user_manage/static/media/user-13.005c80e1.jpg"
  },
  {
    "revision": "eb4e894d949eb0ce8f21368b70f3dd3b",
    "url": "/user_manage/static/media/vuesax-login-bg.eb4e894d.jpg"
  },
  {
    "revision": "0b5207c3b187b13bf16ab81b057ad152",
    "url": "/user_manage/static/media/wireless-earphones.0b5207c3.png"
  }
]);